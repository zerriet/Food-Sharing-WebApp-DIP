<script>
var btn =document.getElementById('btn');

function Toggle(){
if (btn.classList.contains("far")){
	btn.classList.remove("far");
	btn.cassList.add("fas");
	}else{
	bin.classList.remove("far");
	bin.classList.add("fas");
	}
}
</script>
